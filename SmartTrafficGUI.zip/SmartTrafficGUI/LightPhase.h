#pragma once
#include <string>
#include <vector>
#include <windows.h>

class Light {
public:
    virtual std::string name() const = 0;
    virtual int duration() const = 0;
    virtual ~Light() {}
};

class Red : public Light {
public:
    std::string name() const override { return "RED"; }
    int duration() const override { return 5; }
};

class Yellow : public Light {
public:
    std::string name() const override { return "YELLOW"; }
    int duration() const override { return 2; }
};

class Green : public Light {
public:
    std::string name() const override { return "GREEN"; }
    int duration() const override { return 4; }
};

class TrafficPhase {
    std::vector<Light*> lights;
    std::string phaseName;
    int currentIndex = 0;
    int elapsed = 0;
public:
    TrafficPhase(const std::string& n) : phaseName(n) {}
    void addLight(Light* l) { lights.push_back(l); }
    const std::vector<Light*>& getLights() const { return lights; }
    std::string getName() const { return phaseName; }
    std::string currentState() const { return lights.empty() ? "RED" : lights[currentIndex]->name(); }
    int currentDuration() const { return lights.empty() ? 1 : lights[currentIndex]->duration(); }
    void tick() {
        elapsed++;
        if (elapsed >= currentDuration()) {
            elapsed = 0;
            currentIndex = (currentIndex + 1) % (lights.empty() ? 1 : (int)lights.size());
        }
    }
    ~TrafficPhase() { for (auto p : lights) delete p; }
};