#include <windows.h>
#include <string>
#include <vector>
#include "TrafficController.h"

#define IDT_TIMER1 101

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, WndProc, 0, 0,
        GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
        TEXT("SmartTrafficWindowClass"), NULL };
    RegisterClassEx(&wc);
    HWND hwnd = CreateWindow(wc.lpszClassName, TEXT("Smart Traffic Light System"),
        WS_OVERLAPPEDWINDOW, 100, 100, 520, 360, NULL, NULL, wc.hInstance, NULL);
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    // Initialize controller
    TrafficController* controller = new TrafficController(hwnd);

    // Start a timer to update lights (interval 1000ms)
    SetTimer(hwnd, IDT_TIMER1, 1000, NULL);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    KillTimer(hwnd, IDT_TIMER1);
    delete controller;
    UnregisterClass(wc.lpszClassName, wc.hInstance);
    return 0;
}

void drawTrafficLight(HDC hdc, RECT rect, const std::string& state) {
    // draw a vertical box with three circles
    int cx = (rect.left + rect.right) / 2;
    int top = rect.top + 10;
    int radius = 24;
    // box
    Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);
    // red
    HBRUSH brushOff = (HBRUSH)GetStockObject(BLACK_BRUSH);
    HBRUSH brushOn = CreateSolidBrush(RGB(255,0,0));
    HBRUSH brushYellow = CreateSolidBrush(RGB(255,255,0));
    HBRUSH brushGreen = CreateSolidBrush(RGB(0,255,0));

    SelectObject(hdc, brushOff);
    Ellipse(hdc, cx-radius, top, cx+radius, top+2*radius);
    SelectObject(hdc, brushOff);
    Ellipse(hdc, cx-radius, top+3*radius, cx+radius, top+5*radius);
    SelectObject(hdc, brushOff);
    Ellipse(hdc, cx-radius, top+6*radius, cx+radius, top+8*radius);

    if (state == "RED") {
        SelectObject(hdc, brushOn);
        Ellipse(hdc, cx-radius, top, cx+radius, top+2*radius);
    } else if (state == "YELLOW") {
        SelectObject(hdc, brushYellow);
        Ellipse(hdc, cx-radius, top+3*radius, cx+radius, top+5*radius);
    } else if (state == "GREEN") {
        SelectObject(hdc, brushGreen);
        Ellipse(hdc, cx-radius, top+6*radius, cx+radius, top+8*radius);
    }

    DeleteObject(brushOn);
    DeleteObject(brushYellow);
    DeleteObject(brushGreen);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static TrafficController* controller = nullptr;
    switch (msg) {
    case WM_CREATE:
        controller = new TrafficController(hwnd);
        return 0;
    case WM_TIMER:
        if (wParam == IDT_TIMER1) {
            controller->advanceIfNeeded();
            InvalidateRect(hwnd, NULL, TRUE);
        }
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        RECT r;
        GetClientRect(hwnd, &r);
        // draw two traffic lights side by side
        RECT left = {50, 50, 200, 250};
        RECT right = {300, 50, 450, 250};
        drawTrafficLight(hdc, left, controller->getPhaseState("North-South"));
        drawTrafficLight(hdc, right, controller->getPhaseState("East-West"));
        // draw labels
        SetBkMode(hdc, TRANSPARENT);
        TextOut(hdc, left.left, left.bottom + 5, TEXT("North-South"), lstrlen(TEXT("North-South")));
        TextOut(hdc, right.left, right.bottom + 5, TEXT("East-West"), lstrlen(TEXT("East-West")));
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_DESTROY:
        if (controller) { delete controller; controller = nullptr; }
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}
