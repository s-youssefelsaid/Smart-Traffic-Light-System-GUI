#include "TrafficController.h"
#include <map>

TrafficController::TrafficController(HWND hwnd) : hwnd(hwnd) {
    TrafficPhase* phaseNS = new TrafficPhase("North-South");
    phaseNS->addLight(new Green());
    phaseNS->addLight(new Yellow());
    phaseNS->addLight(new Red());

    TrafficPhase* phaseEW = new TrafficPhase("East-West");
    phaseEW->addLight(new Red());
    phaseEW->addLight(new Green());
    phaseEW->addLight(new Yellow());

    phases.push_back(phaseNS);
    phases.push_back(phaseEW);
    lastTick = GetTickCount();
}

TrafficController::~TrafficController() {
    for (auto p : phases) delete p;
}

void TrafficController::advanceIfNeeded() {
    // tick each phase but ensure only one green at a time (simple coordination)
    // tick both phases
    for (auto p : phases) p->tick();
    // simple coordination logic: if NS is GREEN, EW will be RED (handled by phase sequences)
    InvalidateRect(hwnd, NULL, TRUE);
}

std::string TrafficController::getPhaseState(const std::string& name) {
    for (auto p : phases) {
        if (p->getName() == name) return p->currentState();
    }
    return "RED";
}
