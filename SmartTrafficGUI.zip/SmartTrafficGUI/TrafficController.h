#pragma once
#include <string>
#include <vector>
#include <windows.h>

class Light;
class TrafficPhase;

class TrafficController {
    std::vector<TrafficPhase*> phases;
    HWND hwnd;
    unsigned long lastTick;
public:
    TrafficController(HWND hwnd);
    ~TrafficController();
    void advanceIfNeeded();
    std::string getPhaseState(const std::string& name);
};