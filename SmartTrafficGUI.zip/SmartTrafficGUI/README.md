# Smart Traffic Light System (Win32 GUI)

## Overview
A Win32 GUI application (C++ / WinAPI) that simulates a two-phase traffic light intersection.
This project demonstrates OOP concepts (inheritance, polymorphism) and a simple Win32 drawing loop.

## Files
- `main.cpp` - WinMain, window, paint and timer handling.
- `TrafficController.h` / `TrafficController.cpp` - controller managing phases and ticks.
- `LightPhase.h` - Light classes and TrafficPhase definition.
- `README.md` - this file.
- `.gitignore` - Visual Studio ignores.

## How to run (Visual Studio 2022)
1. Create a new empty C++ project (Win32 Console or Empty Project) in Visual Studio 2022.
2. Add the `.cpp` and `.h` files to the project.
3. Set the subsystem to Windows: Project Properties → Linker → System → Subsystem → Windows (/SUBSYSTEM:WINDOWS).
4. Build and Run (F5).

## Notes
- The app uses `SetTimer` to refresh states every second.
- Modify durations in `Light` subclasses for different timings.
